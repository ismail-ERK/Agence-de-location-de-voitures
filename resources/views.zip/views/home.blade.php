@extends('layout.navbar')
@section('content')

<style>
  .uk-inline-container {
    display: block;
}
#marev{  
  transition: opacity 2s linear;  
  transform:translate(0);
  opacity: 1;
}  
.hidden {  
  transform:translate(9999px);
  opacity: 0;  
}
</style>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
@if (Session::has('pdf_send'))
 <script>
     swal("SEND","{!! Session::get('success') !!}","success",{
    button:"ok",})
 </script> 
@endif


    <div class="ftco-blocks-cover-1 ">
      <div class="ftco-cover-1 overlay" style="background-image: url('images/hero_1.jpg')" >
        <br>
        <div class="container">
          <div class="row align-items-center" style="width: 200%">
            <div class="col-md-6" id="marev">

                <form action="{{url('ma_voiture')}}" method="GET">
                  @csrf
            

                  {{ csrf_field() }}
                  {{-- <input type="hidden" name="_method" value="PUT">		 --}}
   
         
              <div class="feature-car-rent-box-1">
                <h3 style="text-align: center">Choisissez votre voiture</h3>
                <ul class="list-unstyled">
                  <div class="form-row">

                  <li class="form-group col-md-6">
                    <label for="ville">Ville</label><br>
                    <input type="text" placeholder="Ville"  name="ville" style="width: 90%" required>
           
                 
                  </li>
                  <li class="form-group col-md-6">
                    <label for="cars">Marque:</label> <br>
                    <select id="marque" name="marque" style="width: 90%" required class="form-select" >
                      @foreach ($Cars as $Car)
                      <option value="{{$Car->marque}}">{{$Car->marque}}</option>

                      @endforeach                     
                    </select>
                 
                  </li>
                  </div>

                  <div class="form-row">

                  <li class="form-group col-md-6">
                    <label for="portes">Nombre de portes </label>
                    <input type="number" placeholder="nombre de portes" name="portes" min="3" max="6" style="width: 90%" required>
                  
                  </li>
                  <li class="form-group col-md-6">
                    <span>
                      <label for=""> </label><br>
                        <select class="form-select" name="transmission"  style="width: 90%">
                         
                        <option selected>choisissez un type de transmission</option>
                        <option value="automatique">automatique</option>
                        <option value="manuel">manuel</option>
                    </select>

                    </span>
                    
                  </li>
                </div>
                  <br>
                  <div class="form-row">

                  <li class="form-group col-md-6">
                    <span>
                    <label for="D_debut">Date debut </label>
                   <input type="date" placeholder="Date debut" name="D_debut" id="D_debut" style="width: 90%">
              
                   @if (count($errors->get('D_debut')))
    

                   <span style="color: red">
                           <ul>
                       @foreach ($errors->get('D_debut') as $message)
                           
                       <li> {{$message}}</li>
                              
                       @endforeach
                           </ul>
                       </span>
                   @endif 
                  </span>
                  </li> 
                  <li style="width: 50%;float: left;">
                    <span>
                    <label for="D_fin">Date fin </label><br>
                    <input type="date" name="D_fin" id="D_fin" style="width: 90%" placeholder="Date fin"> 
                    
                    @if (count($errors->get('D_fin')))
    

                    <span style="color: red">
                            <ul>
                        @foreach ($errors->get('D_fin') as $message)
                            
                        <li> {{$message}}</li>
                               
                        @endforeach
                            </ul>
                        </span>
                    @endif
                  </span>
                  </li> 
                </div>
                <script>
                    oninput="this.parentNode.querySelector(".uk-form-icon").innerText = this.value";

                </script>
                <div class="form-row">
                
       
                        
                        <li class="form-group col-md-6">
                        <div class="uk-form-controls">
                            <div class="uk-inline-container"> <!-- Add -->
                              <span>Prix min (DH) =  </span>
                              <input type="text" class="uk-form-icon uk-form-icon-flip" style="border: solid white" disabled>
                                <input type="range"
                                style="width: 70%"

                                       id="fieldable_form_discount_type_percentage_percentage_amount"
                                       name="prix_min"
                                       min="0" max="10000" step="1"
                                       class="uk-range uk-input"
                                       
                                       oninput="this.parentNode.querySelector('.uk-form-icon').value = this.value">
                            </div>
                            @if (count($errors->get('prix_min')))
    

                            <span style="color: red">
                                    <ul>
                                @foreach ($errors->get('prix_min') as $message)
                                    
                                <li> {{$message}}</li>
                                       
                                @endforeach
                                    </ul>
                                </span>
                            @endif
                        </div>
                        </li>
                        <li class="form-group col-md-6">
                        <div class="uk-form-controls">
                            <div class="uk-inline-container"> <!-- Add -->
                              <span>Prix max (DH/jour) =  </span>
                              <input type="text" class="uk-form-icon uk-form-icon-flip" style="border: solid white" disabled>
                                <input type="range"
                                style="width: 70%"
                                       id="fieldable_form_discount_type_percentage_percentage_amount"
                                       name="prix_max"
                                       min="0" max="10000" step="1"
                                       class="uk-range uk-input"
                                   
                                       oninput="this.parentNode.querySelector('.uk-form-icon').value = this.value">
                            </div>
                            @if (count($errors->get('prix_max')))
    

                            <span style="color: red">
                                    <ul>
                                @foreach ($errors->get('prix_max') as $message)
                                    
                                <li> {{$message}}</li>
                                       
                                @endforeach
                                    </ul>
                                </span>
                            @endif
                        </div>
                        </li>
                    </div>
                
                </div>
                  </div>
                 
                  </li>
                </div>
                </ul>
                <div  style="text-align: center">
                 
                  <input type="submit" class="ml-auto btn btn-primary" value="Cercher">
                </div>
                     
            </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

   

    

    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <h3>Nos offres</h3>
            <p class="mb-4">Découvrez nos top voitures </p>
            <p>
              <a href="#" class="btn btn-primary custom-prev">Previous</a>
              <span class="mx-2">/</span>
              <a href="#" class="btn btn-primary custom-next">Next</a>
            </p>
          </div>


          <div class="col-lg-9">

            @if (!session()->exists('ch'))
    


            <div class="nonloop-block-13 owl-carousel">
              @foreach ($Voitures as $voiture)
            
          <div class="item-1">
              <a href="{{url('infoV/'.$voiture->num_immatriculation)}}" ><img style="height: 250px"  src="{{asset('imagess/'.$voiture->url)}}" alt="Image" class="img-fluid"></a>
               <div class="item-1-contents">
                <div class="text-center">
                <h3><a href="{{url('infoV/'.$voiture->num_immatriculation)}}">{{$voiture->marque}}</a></h3>
                <div class="rating">
                  @for ($i = 0; $i < ceil($voiture->value); $i++)
                  <span class="icon-star text-warning"></span>
@endfor
@for ($i = $voiture->value +1  ; $i <= 5; $i++)
<span class="icon-star text-muted"></span>
@endfor
                </div>
                <div class="rent-price"><span>{{$voiture->prix_jour}}/</span>day</div>
                </div>
                <ul class="specs">
                  <li>
                    <span>Nombre de location</span>
                    <span class="spec">{{$voiture->nombre_location}}</span>
                  </li>
                  <li>
                    <span>Seats</span>
                    <span class="spec">{{$voiture->nombre_places}}</span>
                  </li>
                  <li>
                    <span>Transmission</span>
                    <span class="spec">{{$voiture->transmission}}</span>
                  </li>
                  <li>
                    <span>Couleur</span>
                    <span class="spec">{{$voiture->couleur}}</span>
                  </li>
                </ul>
                <div class="d-flex action">
                  <a href="{{ url('louer/'.$voiture->num_immatriculation)}}" class="btn btn-primary">Rent Now</a>
                </div>
              </div>
            </div>
      
        @endforeach 
           </div>



            </div>
            
        @endif  
          </div>
        </div>
      </div>
  

    <div class="site-section section-3" style="background-image: url('images/hero_2.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-12 text-center mb-5">
            <h2 class="text-white">Nos services</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4">
            <div class="service-1">
              <span class="service-1-icon">
                <span class="flaticon-car-1"></span>
              </span>
              <div class="service-1-contents">
                <h3>Location</h3>
                <p>Nous offrons une variété de voitures à louer à bon prix !</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="service-1">
              <span class="service-1-icon">
                <span class="flaticon-traffic"></span>
              </span>
              <div class="service-1-contents">
                <h3>Offres diverses</h3>
                <p>Divers marques, Divers versions et Divers catégories de voitures !  </p>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="service-1">
              <span class="service-1-icon">
                <span class="flaticon-valet"></span>
              </span>
              <div class="service-1-contents">
                <h3>Paiement en ligne</h3>
                <p>Possibilité d'effectuer un paiement en ligne : Sécurisé et rapide ! </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="container site-section mb-5">
      <div class="row justify-content-center text-center">
        <div class="col-7 text-center mb-5">
          <h2>How it works</h2>
          <p>Avec des simples clicks et en quelques secondes vous pouvez louer la voiture que vous aimez ! </p>
        </div>
      </div>
      <div class="how-it-works d-flex">
        <div class="step">
          <span class="number"><span>01</span></span>
          <span class="caption">Time &amp; Place</span>
        </div>
        <div class="step">
          <span class="number"><span>02</span></span>
          <span class="caption">Car</span>
        </div>
        <div class="step">
          <span class="number"><span>03</span></span>
          <span class="caption">Details</span>
        </div>
        <div class="step">
          <span class="number"><span>04</span></span>
          <span class="caption">Checkout</span>
        </div>
        <div class="step">
          <span class="number"><span>05</span></span>
          <span class="caption">Done</span>
        </div>

      </div>
    </div>
    
    
   


    <div class="site-section bg-white">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-7 text-center mb-5">
            <h2>Our Blog</h2>
            
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="post-entry-1 h-100">
              <a href="single.html">
                <img src="images/post_1.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                
                <h2><a href="single.html">Les informations que vous devez savoir sur une voiture</a></h2>
                <span class="meta d-inline-block mb-3">June 02, 2021 </span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores eos soluta, dolore harum molestias consectetur.</p>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="post-entry-1 h-100">
              <a href="single.html">
                <img src="images/img_2.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                
                <h2><a href="single.html">Ce que vous devez faire en cas d'accident</a></h2>
                <span class="meta d-inline-block mb-3">July 17, 2019 <span class="mx-2">by</span> <a href="#">Admin</a></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores eos soluta, dolore harum molestias consectetur.</p>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mb-4">
            <div class="post-entry-1 h-100">
              <a href="single.html">
                <img src="images/img_3.jpg" alt="Image"
                 class="img-fluid">
              </a>
              <div class="post-entry-1-contents">
                
                <h2><a href="single.html">Découverez les nouveautés des voitures </a></h2>
                <span class="meta d-inline-block mb-3">July 17, 2019 <span class="mx-2">by</span> <a href="#">Admin</a></span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores eos soluta, dolore harum molestias consectetur.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    

    @include('layout.footer')

    </div>

    @endsection

  