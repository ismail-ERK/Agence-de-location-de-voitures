<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>

 
   
    <p>{{$details['body1']}}</p>
    <p>{{$details['body2']}}</p>
    <p>{{$details['body3']}}</p>
</body>
</html>