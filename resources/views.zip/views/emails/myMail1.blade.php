<!DOCTYPE html>
<html>
<head>
    <title>EMERGENCY FROM CLIENT</title>
</head>
<body>
   
<h1>{{$details['em']}}</h1>
 
    <p>{{$details['body1']}}</p>
    <p> {{$details['body4']}}</p>
    <p> {{$details['body2']}}</p>
    <p>{{$details['body3']}}</p>

</body>
</html>