<!DOCTYPE html>
<html>
<head>
    <title>Contrat</title>
</head>
<body>
    <h1>Voici votre contrat M.{{Auth::user()->name}}</h1>
  <p>Merci</p>
</body>
</html>