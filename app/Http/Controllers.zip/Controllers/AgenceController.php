<?php

namespace App\Http\Controllers;
use App\Http\Controllers\AgenceController;
use App\Models\Agence;
use App\Models\Voiture;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class AgenceController extends Controller
{
   public function indexA(){
    $Agences = Agence::all();
    return view('pages.Nos_agences')->with('Agences', $Agences);
   }


   

   public function chaque_agence($id){
      $agence = Agence::select("*")
      ->where('id_agence', $id)
      ->first();
      
      $Voitures =  Voiture::select("*")
->where('id_agence', $id)

->get();






      return view('pages.Mes_agences')->with('Voitures',$Voitures)->with('agence', $agence); 
  }

  public function confirm(){
    
session()->flash('vv','ok');





      return redirect()->back(); 
  }


}
